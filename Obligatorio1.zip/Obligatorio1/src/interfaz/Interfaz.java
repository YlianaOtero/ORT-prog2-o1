package interfaz;

/** Interfaz es la clase del metodo main. La ejecucion se da en esta clase.
 * @author yliana*/

public class Interfaz extends Sistema{
    public static void main(String[] args) {
        Sistema.menuInicial();
    }
}
